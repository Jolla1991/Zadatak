#include <iostream>
#include <algorithm>
#include <iomanip>
#include <conio.h>

using namespace std;
const int BrojA = 100;  // maskimalni broj artikala u ponudi vocarne
const char separator    = ' ';
const int nameWidth     = 33;
const int numWidth      = 8;
const int nameWidth_2     = 30;
const int numWidth_2      = 8;

class VOCE{
public:
    string ime;
    double tezina;
    double cijena_po_kg;

    VOCE(){
    ime = "Prazni artikal";
    tezina = 0;
    cijena_po_kg = 0;
    }
};
//-----------------------------------------------------------------------------//
//Ispis sivih artikala trenutno na stanju
void Ispis_artikala(int j, VOCE ar[BrojA]){
    cout << endl;
    cout << left << setw(nameWidth_2) << setfill(separator) << "Naziv artikla";
    cout << left << setw(nameWidth_2) << setfill(separator) << "Kolicina (kg)";
    cout << left << setw(nameWidth_2) << setfill(separator) << "Cijena (kn/kg)";
    cout << endl;
    for (int i = 0; i < j; i++) {
        cout << left << setw(nameWidth) << setfill(separator) << ar[i].ime;
        cout << left << setw(nameWidth) << setfill(separator) << ar[i].tezina;
        cout << left << setw(nameWidth) << setfill(separator) << ar[i].cijena_po_kg;
        cout << endl;
    }
    cout << endl;
    cout << "Vocarna nudi maksimalno ";
    cout << BrojA;
    cout << " artikala u ponudi."<< endl;
    cout << endl;
}
//-----------------------------------------------------------------------------//
//Komparator za sortiranje artikala po cijeni kilograma
bool Komparacija(VOCE const & a, VOCE const & b){
    return a.cijena_po_kg > b.cijena_po_kg;
}
//-----------------------------------------------------------------------------//
//Pretrazivanje artikla prema imenu i ispsivanje stanja pronađenog artikla
void Upit(int BrojArtikala, VOCE ar[BrojA]){
  string Pime;
  int marker = 0;
  int p;
  cout << "Ime voca kojeg trazis u vocarni ili nula za povratak: ";
  Skok_1:cin >> Pime;
  if (Pime != "0"){
    for (int i = 0; i < BrojArtikala; i++){
        if (ar[i].ime == Pime){
            marker = 1;
            p = i;
            goto Skok_2;
        }
    }
  }else{
  goto Skok_3;
  }
  Skok_2:if (marker == 1){
    cout << endl;
    cout << "Artikal je u ponudi!"<< endl;
    cout << endl;
    cout << "Kolicina artikla u kilogramima: ";
    cout << ar[p].tezina << endl;
    cout << "Cijena po kilogramu artikla (kn/kg): ";
    cout << ar[p].cijena_po_kg << endl;
  }else{
    cout << "Artikal nije u ponudi!" << endl;
    cout << "Uensi artikal ponovno ili nula za povratak:" << endl;
    goto Skok_1;
  }
Skok_3: cout <<  endl;
}
//-----------------------------------------------------------------------------//
//Kupovina
void Kupovina(int BrArtikala, VOCE ar[BrojA]){
    string Kime;
    double cijena = 0;
    double KTetina, Plati;
    string odabir;
    int zastava_1 = 0;
    int zastava_2 = 0;
    int p,Opcija;
    int marker = 0;

    cout << "Ime voca kojeg kupujes ili nulu za povratak: ";
    Skok_2:cin >> Kime;
    if (Kime != "0"){
        for (int i = 0; i < BrArtikala; i++){
            if (ar[i].ime == Kime){
                marker = 1;
                p = i;
                goto Skok_1;
            }
        }

    }else{
        goto Skok_3;
    }

    Skok_1:if (marker == 1){
        cout << endl;
        cout << "Artikal je u ponudi!"<< endl;
        cout << "" << endl;
        cout << "Unos kolicine voca u kilogramima koju kupujes: ";
        cin >> KTetina;
    }else{
        cout << "Artikal nije u ponudi!" << endl;
        cout << "Unesi drugi artikal ili nulu za izlaz: " << endl;
        goto Skok_2;
    }

    Skok_5:if(ar[p].tezina > KTetina){
        cijena = ar[p].cijena_po_kg * KTetina;
        cout << endl;
        cout << "Cijena za odabranu tezinu artikla iznosi: ";
        cout << cijena << endl;
        zastava_1 = 1;
        zastava_2 = 0;
        goto Skok_4;
    }else{
        cijena = ar[p].cijena_po_kg * ar[p].tezina;
        cout << "Odabrana tezina artikla veca je od zaliha vocarne! Kolicina zalihe je: ";
        cout << ar[p].tezina << endl;
        cout <<"cijena za cijelu zalihu vocarne iznosi: ";
        cout << cijena << endl;
        zastava_2 = 1;
        zastava_1 = 0;
        goto Skok_4;
    }

    Skok_4:cout << "Zelite kupiti artikal? (da/ne)" << endl;
    cin >> odabir;
    if (odabir == "da" && zastava_1){
        ar[p].tezina = ar[p].tezina - KTetina;
        goto Skok_6;
    }else if (odabir == "da" && zastava_2){
        ar[p].tezina = 0;
        goto Skok_6;
    }else if(odabir == "ne"){
        cout << endl;
        cout << "Niste htijeli kupiti artikal!" << endl;
        cout <<  endl;
        zastava_1 = 0;
        zastava_2 = 0;
        Skok_8:cout << "Zelite li: " << endl;
        cout << "1. Promijeniti kolicinu artikla \n";
        cout << "2. Promijeniti artikla \n";
        cout << "3. Izaci iz procesa kupovine \n";
        cout << "Upisi broj opcije: ";
        cin >> Opcija;
    }


    switch(Opcija){
    case 1:
        cout <<  endl;
        cout << "Unos nove kolicine voca u kilogramima: ";
        cin >> KTetina;
        zastava_1 = 0;
        zastava_2 = 0;
        Opcija = 0;
        goto Skok_5;
    case 2:
        cout <<  endl;
        cout << "Odlucili ste se za promijenu artikla! Unesite novi artikal ili nulu za povratak:";
        goto Skok_2;
    case 3:
        goto Skok_3;
    default:
        cout <<  endl;
        cout << "Za uneseni broj ne postoji opcija, pokusajte ponovo." << endl;
        goto Skok_8;
        break;
    }
 Skok_6:cout <<  endl;
 cout << "Molimo vas da platite naruceno voce, tako da unesete izracunatu cijenu: ";
 cin >> Plati;
 if (cijena == Plati){
    cout <<  endl;
    cout << "Hvala vam na kupovini, dodte opet!" << endl;
    goto Skok_7;
 }else{
     cout <<  endl;
     cout << "Unjeli se krivi iznos! Potrebno je platiti:";
     cout << cijena << endl;
     goto Skok_6;
 }

 Skok_3:cout << "Izlaz iz Kupovine!" << endl;
 Skok_7:cout<< endl;
}
//-----------------------------------------------------------------------------//
//Dodavanje novog voca u ponudu
int UnosNovogVoca (int BrNovogArtikla, VOCE ar[BrojA]){
    string UNV;
    cout << "Dodaj novo voce ili unesi nulu za povratak: ";
    cin >> UNV;
    if (UNV != "0"){
        BrNovogArtikla = BrNovogArtikla + 1;
        cout << "Naziv novog artikla: ";
        ar[BrNovogArtikla].ime = UNV;
        cout << ar[BrNovogArtikla].ime << endl;
        cout << "Kolicina artikla u kilogramima: ";
        cin >> ar[BrNovogArtikla].tezina;
        cout << "Cijena po kilogramu artikla (kn/kg) :";
        cin >> ar[BrNovogArtikla].cijena_po_kg;
        cout <<  endl;
    }

    return BrNovogArtikla;
}
//-----------------------------------------------------------------------------//
//Brisanje artikla iz ponude
int BrisanjePostojecegArtikla (int BrNakonBrisanja, VOCE ar[BrojA]){
    string ImeArtiklaZaBrisanje;
    string odabir;
    int marker = 0;
    int p;
    cout << "Naziv artikla kojeg zelite izbaciti iz ponude ili nula za povratal: ";
    Skok_2:cin >> ImeArtiklaZaBrisanje;
    if (ImeArtiklaZaBrisanje != "0"){
         for (int i = 0; i < BrNakonBrisanja; i++ ){
            if (ar[i].ime == ImeArtiklaZaBrisanje){
                marker = 1;
                p = i;
                cout << endl;
                cout << "Artikal je u ponudi!"<< endl;
                cout << endl;
                goto Skok_1;
            }
         }
    }else{
        goto Skok_3;
    }
    Skok_1:cout << "Potvrdite da zelite obrisati artikal! (da/ne)";
    Skok_4:cin >> odabir;
    if (odabir == "da" || odabir == "ne"){
        goto Skok_5;
    }else{
        cout << endl;
        cout << "Treba unjeti da ili ne za odabir pokusajte ponovo!";
        cout << endl;
        goto Skok_4;
    }
    Skok_5:if (marker == 1 && odabir == "da"){
        ar[p].ime = "Prazni artikal";
        ar[p].tezina = 0;
        ar[p].cijena_po_kg = 0;
        BrNakonBrisanja = BrNakonBrisanja - 1;
        cout << endl;
        cout << "Artikal je obrisan iz ponude!!"<< endl;
        cout << endl;
    }else if(marker == 1 && odabir == "ne"){
        cout << "Unesite novi artikla kojeg zelite izbaciti iz ponude ili nula za povratal: ";
        goto Skok_2;
    }else{
        cout << "Takav artikal ne postoji! Unesi drugi ili nulu za izlaz";
        goto Skok_2;
    }
    Skok_3:return BrNakonBrisanja;
}
//-----------------------------------------------------------------------------//
//Izmjena artikla
void Izmjena(int TrenutniBrojArtikala, VOCE ar[BrojA]){
    string ImeArtiklaZaIzmjenu;
    string Iime, odabir;
    double Itezina;
    double Icijena_po_kg;
    int marker = 0;
    int p;
    cout << "Naziv artikla kojeg zelite izmjeniti u ponudi ili nulu za izlaz: ";
    Skok_3:cin >> ImeArtiklaZaIzmjenu;
    if (ImeArtiklaZaIzmjenu != "0"){
        for (int i = 0; i < TrenutniBrojArtikala; i++ ){
            if (ar[i].ime == ImeArtiklaZaIzmjenu){
                marker = 1;
                p = i;
                goto Skok_1;
            }
        }
    }else{
        goto Skok_2;
    }
    Skok_1:if (marker == 1){
        cout << "Želite li u potpunosti zamjeniti odabrani artikal novim (da/ne): ";
        Skok_4:cin >> odabir;
        if (odabir == "da"){
            cout << "Naziv novog artikla: ";
            cin >> Iime;
            ar[p].ime = Iime;
            cout << "Kolicina artikla u kilogramima: ";
            cin >> Itezina;
            ar[p].tezina = Itezina;
            cout << "Cijena po kilogramu artikla (kn/kg) :";
            cin >> Icijena_po_kg;
            ar[p].cijena_po_kg = Icijena_po_kg;
        }else if (odabir == "ne"){
            cout << "Kolicina artikla u kilogramima: ";
            cin >> Itezina;
            ar[p].tezina = Itezina;
            cout << "Cijena po kilogramu artikla (kn/kg) :";
            cin >> Icijena_po_kg;
            ar[p].cijena_po_kg = Icijena_po_kg;
        }else{
            cout << "Nije upisano da ili ne, molimo da upišete predložene opcije!";
            goto Skok_4;
        }

    }else{
        cout << "Artikal nije u ponudi!" << endl;
        cout << "Uensi artikal ponovno ili nula za povratak:" << endl;
        goto Skok_3;
    }
    Skok_2: cout << "" << endl;
}
//-----------------------------------------------------------------------------//
int main()
{
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
/* Popis varijabli */

    int Izbornik_1; // Zapis korisnièkog odabira opcije izornika
    int Izbornik_2; // Zapis korisničkog izbora unutar Opcije UPRAVALJANJE SKLADISTEM
    int TBA = 6; // TBA = Trenutni broj artikala
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    /*Insance clase VOCE, kje su predefinirane u programu*/
    VOCE ListaVoca[BrojA];

    ListaVoca[0].ime = "Jabuka";
    ListaVoca[0].tezina = 70;
    ListaVoca[0].cijena_po_kg = 15;

    ListaVoca[1].ime = "Banana";
    ListaVoca[1].tezina = 20;
    ListaVoca[1].cijena_po_kg = 10;

    ListaVoca[2].ime = "Kruska";
    ListaVoca[2].tezina = 40;
    ListaVoca[2].cijena_po_kg = 25;

    ListaVoca[3].ime = "Tresnja";
    ListaVoca[3].tezina = 150;
    ListaVoca[3].cijena_po_kg = 3;

    ListaVoca[4].ime = "Smokva";
    ListaVoca[4].tezina = 3;
    ListaVoca[4].cijena_po_kg = 40;

    ListaVoca[5].ime = "Grozde";
    ListaVoca[5].tezina = 50;
    ListaVoca[5].cijena_po_kg = 5;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
//Sortiranje liste
sort(ListaVoca, ListaVoca + BrojA, Komparacija);
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    /* Glavni izbornik*/
    Skok_1:cout << "######     Vocarna Vocko, Doboro dosli!     ######\n\n" << endl; //Vrati_se_na_prvi_izbornik je label na koji skačemo nakon izlska iz svakog menija
    cout << "1. Upravljanje skladistem" << endl ;
    cout << "2. Upit" << endl;
    cout << "3. Kupovina" << endl;
    cout << "4. Izlaz\n" << endl;

    cout << "Unesite broj zeljene opcije: ";
    cin >> Izbornik_1;
    cout << endl;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    switch(Izbornik_1){

    /*Ovisno o odabiru izbornika ispisje se adekvatni pod izbornik*/
    case 1:
        cout << "1. Dodavanje" << endl;
        cout << "2. Brisanje" << endl;
        cout << "3. Stanje" << endl;
        cout << "4. Izmjena" << endl;
        cout << "5. Povratak" << endl;
        cout <<  endl;
        cout << "Unesite broj zeljene opcije: ";
        cin >> Izbornik_2;
        cout << endl;
        goto Skok_2;
        break;
    case 2:
         Upit(TBA,ListaVoca);
        goto Skok_1;
    case 3:
        Kupovina(TBA,ListaVoca);
        goto Skok_1;
    case 4:
        goto izlaz;
        break;
    default:
        cout << "Odabrana opcija ne postoji! Upisite broj koji se nalazi ispred opcije." << endl;
        cout << endl;
        goto Skok_1;

    }
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    Skok_2: switch(Izbornik_2){

    /*Ovisno o odabiru izbornika aktivira se odredena funkcija*/
    case 1:
        TBA = UnosNovogVoca(TBA, ListaVoca);
        sort(ListaVoca, ListaVoca + BrojA, Komparacija);
        goto Skok_1;
    case 2:
        TBA = BrisanjePostojecegArtikla(TBA, ListaVoca);
        sort(ListaVoca, ListaVoca + BrojA, Komparacija);
        goto Skok_1;
    case 3:
        Ispis_artikala(TBA,ListaVoca);
        goto Skok_1;
    case 4:
        Izmjena(TBA,ListaVoca);
        sort(ListaVoca, ListaVoca + BrojA, Komparacija);
    case 5:
        goto Skok_1;
    }

    izlaz:cout<<"Kraj Programa"<< endl;
    return 0;
}
